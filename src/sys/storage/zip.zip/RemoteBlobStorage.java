package sys.storage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import org.apache.kafka.clients.consumer.ConsumerRecords;

import api.storage.BlobStorage;
import api.storage.Datanode;
import api.storage.Namenode;
import kafka.Subscriber;
import sys.storage.io.BufferedBlobReader;
import sys.storage.io.BufferedBlobWriter;
import utils.MapReduceCommon;
import utils.ServiceDiscovery;

public class RemoteBlobStorage implements BlobStorage {
	private static final int BLOCK_SIZE = 512;

	private static Logger logger = Logger.getLogger(RemoteBlobStorage.class.getName());

	private static boolean kafka = false;
	
	private String datanodeCopy;

	Namenode namenode;
	Map<String, Namenode> namenodes;
	Map<String, Datanode> datanodes;

	public RemoteBlobStorage() {

		datanodes = new ConcurrentHashMap<String,Datanode>();
		namenodes = new ConcurrentHashMap<String, Namenode>();

		if(!kafka) {

			Thread dataNodeDiscovery = new Thread() {
				
				public void run() {
					
					Map<String, String> datanodesCountmap = new ConcurrentHashMap<String, String>();
					double initialTime = System.currentTimeMillis();
					
					while(true) {
						String[] datanodeNames = ServiceDiscovery.multicastSend(ServiceDiscovery.DATANODE_SERVICE_NAME);
						if(datanodeNames != null) {
							for(String datanode: datanodeNames) {
								datanodesCountmap.putIfAbsent(datanode, datanode);
								if(datanodes.putIfAbsent(datanode, new DatanodeClient(datanode)) != null) {
									logger.info("New Datanode discovered: " + datanode);
								}
							}
						}
						
						double currentTime = System.currentTimeMillis();
						
						if((currentTime - initialTime) > 5000) {
							
						for (String varDatanode : datanodesCountmap.keySet()) {
							if(datanodes.containsKey(varDatanode))
								datanodesCountmap.remove(varDatanode);
						}
						for (String dataNtoRemove : datanodeNames) {
							datanodes.remove(dataNtoRemove);
						}
						
						
						/*
						 * so we got now the missing datanodes
						 * 1st we need to get the blobs that need to be replicated to other datanodes
						 * 2nd we got to write and this time we will right 2 more copies
						 * 3 we need to update the namenode DB 
						 */
						Namenode rdmNamenode = namenodes.get(randomNamenode());
						
						
						datanodesCountmap.keySet().forEach(datanode -> {
							List<String> blobs =rdmNamenode.read(datanode);
							rdmNamenode.delete(datanode);
							datanodeCopy = null;
							
							blobs.forEach(blob -> {
								
								for (String datanodeToCheck : datanodes.keySet()) {
									if(rdmNamenode.list(datanodeToCheck).contains(blob)) {
										datanodeCopy = datanodeToCheck;
										break;
									}
										
								}
								if(datanodeCopy != null) {
								String randomDatanodeKey = randomDatanode();
								Datanode datanodeToRead = datanodes.get(datanodeCopy);
								Datanode datanodeToWrite = datanodes.get(randomDatanodeKey);
								List<String> blocks = rdmNamenode.read(blob);
								
								blocks.forEach(block -> {
									datanodeToWrite.createBlock(datanodeToRead.readBlock(block));
									
									
								});
								//create or update QUESTIONMARK TIAGOO
								//rdmNamenode.create(randomDatanodeKey, blocks);
								
								//STILL A QUESTIONMARK TIAGOO xD
								System.err.println(blob);
								rdmNamenode.update(blob, blocks);
								}
							});
							
							//FUCK YOU MISSING DATANODE
							
							//THAT FUCKING IT GUYS ARE EATING DONUTS OR WHAT
							rdmNamenode.delete(datanode);
						});
						initialTime = System.currentTimeMillis();
						datanodesCountmap = new ConcurrentHashMap<>();
						}


						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							//nothing to be done
						}
					}
				}
			};
			dataNodeDiscovery.start();

			while(true) {
				String[] namenodename = ServiceDiscovery.multicastSend(ServiceDiscovery.NAMENODE_SERVICE_NAME);
				for (int i = 0; i < namenodename.length; i++) {
					if(namenodes.putIfAbsent(namenodename[i], new NamenodeClient(namenodename[i])) != null) {
						logger.info("Namenode discovered: " + namenodename[i]);
					}
				}
				break;
			}	
		}
		else {
			Thread datanodeKafkaDiscovery = new Thread() {
				public void run() {

					Collection<String> topics = new ArrayList<String>(Arrays.asList(new String[] { "Datanode", "Namenode" }));

					Subscriber sub = new Subscriber(topics);

					while(true) {
						ConsumerRecords<String,String> records = sub.info();
						if(records != null) {
							records.forEach(record -> {
								if(record.topic().equals("Datanode")) {
									if(datanodes.putIfAbsent(record.value(), new DatanodeClient(record.value())) != null) {
										logger.info("New Datanode discovered: " + record.value());
									}


								}
								if(record.topic().equals("Namenode")) {
									if(namenodes.putIfAbsent(record.value(), new NamenodeClient(record.value())) != null) {
										logger.info("Namenode discovered: " + record.value());
									}

								}

							}); 	
						}

						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							//nothing to be done
						}
					}

				}
			};
			datanodeKafkaDiscovery.start();
		}	
	}

	private String randomNamenode() {
		Random random = new Random();
		List<String> keys = new ArrayList<String>(namenodes.keySet());
		String randomKey = keys.get( random.nextInt(keys.size()) );

		return randomKey;

	}
	private String randomDatanode() {
		Random random = new Random();
		List<String> keys = new ArrayList<String>(datanodes.keySet());
		String randomKey = keys.get( random.nextInt(keys.size()) );
		
		return randomKey;
	}
	

	@Override
	public List<String> listBlobs(String prefix) {
		return namenodes.get(randomNamenode()).list(prefix);
	}

	@Override
	public void deleteBlobs(String prefix) {
		Namenode rdmNamenode = namenodes.get(randomNamenode());
		rdmNamenode.list(prefix).forEach(blob -> {
			rdmNamenode.read(blob).forEach(block -> {
				String[] components = MapReduceCommon.getAddressFromBlockUUID(block);
				if(components != null && datanodes.containsKey(components[0])) {
					datanodes.get(components[0]).deleteBlock(components[1]);
				}
			});
		});
		rdmNamenode.delete(prefix);
	}


	@Override
	public BlobReader readBlob(String name) {
		Namenode rdmNamenode = namenodes.get(randomNamenode());
		logger.info("readBlob(" + name + ")");
		logger.info("Namenode is: " + ((NamenodeClient) rdmNamenode).address);
		for(String addr: datanodes.keySet()) {
			logger.info("Datanode: " + addr);
		}
		return new BufferedBlobReader(name, namenode, datanodes);
	}

	@Override
	public BlobWriter blobWriter(String name) {
		Namenode rdmNamenode = namenodes.get(randomNamenode());

		return new BufferedBlobWriter(name, rdmNamenode, datanodes, BLOCK_SIZE);
	}
}
